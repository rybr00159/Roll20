# Someone Must Hurt — Roll20 pack

Four NPC imports for the legacy D&D 5E by Roll20 sheet, using 2014 rules. The supplied encounter targets five 8th-level characters. All source AC, HP, abilities, saves, skills, attack bonuses, damage, CRs and XP were preserved. Challenge ratings are the source's homebrew design estimates.

## Import

1. Extract this ZIP. If ChatGPT Importer is already installed in your Roll20 Pro game, use that installation. Otherwise create one Mod script, paste the complete ChatGPTImporter.js, and save; enter !gpt-help as GM to check it is running.
2. Create a private handout named **GPT Import**. Copy one npc-*.json file into **Description & Notes**, then save. Copy only the complete JSON object.
3. Run these two chat commands as GM:

```text
!gpt-check-handout GPT Import
!gpt-import-handout GPT Import
```

4. Open the created NPC sheet, let its workers finish, and check HP, AC and a weapon attack. Repeat with each of the other three JSON files, reusing the saved handout. Existing character names are refused; one import represents all tokens of that monster type.

| File | Monster | AC | HP | CR |
| --- | --- | --- | --- | --- |
| npc-suture-attendant.json | Suture Attendant | 15 | 60 | 2 |
| npc-many-handed-crawler.json | The Rejected: Many-Handed Crawler | 15 | 102 | 5 |
| npc-spinal-crawler.json | The Rejected: Spinal Crawler | 16 | 110 | 5 |
| npc-matron-yselle.json | Matron Yselle, the Anatomist of Mercy | 17 | 170 | 10 |

All four monsters are Medium: one grid square each on a 5-foot grid. Repeated attendant tokens need separate unlinked HP bars (60/60), so damage to one does not change every copy. Both Yselle portraits use one sheet and one 170-HP pool. Artwork is not included in the uploaded Markdown or this pack.

Weapon actions roll attacks and damage. Multiattack, saving throws, conditions, recharge, limited uses, reactions and legendary-action spending require manual resolution. Yselle's Bone Scalpel includes both 2d8+4 slashing and 1d6 necrotic; she has 2 legendary actions and no Spellcasting trait.

Create a private handout from **GM-REFERENCE.md** for the living chamber, three conduits, suspended heart, encounter counts and timers. These objects use ordinary tokens with unlinked HP bars; they are not creature imports. Original adventure endings and other omitted rules remain in the original adventure.

**SOURCE-STATBLOCKS.md** retains the uploaded source. **manifest.json** records archive contents and SHA-256 checksums. JSON validation and local attribute checks passed; no live Roll20 game was accessed. Importing does not automatically attach artwork or configure token vision, ownership or HP bars.

[Repository guide and updates](https://github.com/rybr00159/Roll20/blob/main/docs/monsters/someone-must-hurt.md)
